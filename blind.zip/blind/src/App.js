import React, { useState } from 'react';
import { useSwipeable } from 'react-swipeable';
import './App.css';

export default function SwipeMenu() {
  const [menu, setMenu] = useState("Home");

  const handleSwipe = (direction) => {
    switch (direction) {
      case "Left":
        setMenu("Menu 1");
        break;
      case "Right":
        setMenu("Menu 2");
        break;
      case "Up":
        setMenu("Menu 3");
        break;
      case "Down":
        setMenu("Menu 4");
        break;
      default:
        setMenu("Home");
    }
  };

  const swipeHandlers = useSwipeable({
    onSwipedLeft: () => handleSwipe("Left"),
    onSwipedRight: () => handleSwipe("Right"),
    onSwipedUp: () => handleSwipe("Up"),
    onSwipedDown: () => handleSwipe("Down"),
    preventDefaultTouchmoveEvent: true,
    trackTouch: true,
    trackMouse: true,
  });

  return (
    <div {...swipeHandlers} className="menu-container">
      <div className="menu">
        <h1>{menu}</h1>
      </div>
    </div>
  );
}
